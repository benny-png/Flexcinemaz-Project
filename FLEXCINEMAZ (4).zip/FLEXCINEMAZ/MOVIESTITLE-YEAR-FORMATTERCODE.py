import re
import csv

# Read the cleaned text file
with open('clean.txt', 'r') as file:
    lines = file.readlines()

# Initialize a list to store movie data
movie_data = []

# Define a regular expression pattern to match the movie titles, years, and links
pattern = r'download-(.*?)-(\d{4})/download'

# Extract movie titles, years, and links
for line in lines:
    match = re.search(pattern, line)
    if match:
        movie_title, year = match.groups()
        # Replace hyphens with spaces in the movie title
        movie_title = movie_title.replace('-', ' ')
        movie_link = line.strip()  # Strip to remove extra whitespace
        movie_data.append((movie_title, year, movie_link))

# Write the data to a CSV file
with open('NETNAIJAORGANIZEDMOVIES.csv', 'w', newline='') as csvfile:
    csv_writer = csv.writer(csvfile)
    csv_writer.writerow(['movie_title', 'year', 'movie_link'])
    csv_writer.writerows(movie_data)

print("Data has been written to 'NETNAIJAORGANIZEDMOVIES.csv'")
