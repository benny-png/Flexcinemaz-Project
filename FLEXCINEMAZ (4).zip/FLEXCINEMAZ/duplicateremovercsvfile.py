import csv

# Define the input and output file paths
input_file = 'NETNAIJAORGANIZEDMOVIES_WITH_TRAILERS.csv'
output_file = 'UniqueMovies.csv'

# Create sets to track unique titles
unique_titles = set()
unique_rows = []

# Read the CSV file and remove duplicates based on "MOVIE_TITLE"
with open(input_file, 'r', newline='') as infile:
    reader = csv.DictReader(infile)
    fieldnames = reader.fieldnames
    
    for row in reader:
        movie_title = row['MOVIE_TITLE']
        
        # Check if the title is not in the set of unique titles
        if movie_title not in unique_titles:
            unique_titles.add(movie_title)
            unique_rows.append(row)

# Write the unique rows to a new CSV file
with open(output_file, 'w', newline='') as outfile:
    writer = csv.DictWriter(outfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(unique_rows)

print(f"Removed duplicates based on MOVIE_TITLE. Unique rows saved to {output_file}")
