from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import csv
import time

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the URL of the webpage to scrape movie data
movie_url = "https://www.themoviedb.org/movie/"

base_url = "https://www.themoviedb.org"

# Open the URL
driver.get(movie_url)

# Initialize a set to track unique movie IDs
unique_movie_ids = set()

# Initialize an empty list to store the movie data
movie_data = []

# Function to extract and add movie data to the list
def extract_movie_data():
    movie_elements = driver.find_elements(By.CSS_SELECTOR, "a[href^='/movie/'][title]")

    for element in movie_elements:
        href = element.get_attribute("href")
        title = element.get_attribute("title")
        movie_id = href.split("/movie/")[1]
        if movie_id not in unique_movie_ids:
            unique_movie_ids.add(movie_id)
            movie_data.append({"MOVIE_ID": movie_id, "TITLE": title})
            print(f"Added {len(movie_data)} movies")

# Click the "Load More" link with href="/movie/?page="
def click_load_more():
    try:
        load_more_link = driver.find_element(By.XPATH, "//div[@id='page_1']//div[@id='pagination_page_1']//a[@class='no_click load_more']")
        driver.execute_script("arguments[0].scrollIntoView();", load_more_link)
        load_more_link.click()
        time.sleep(2)  # Add a delay to let the new movies load
        print("Clicked 'Load More' to load additional movies")
    except Exception as e:
        print("No 'Load More' link found or reached the end.")

# Click the "Load More" link until at least 100 unique movies have been collected
while len(movie_data) < 2500:
    extract_movie_data()
    click_load_more()
    SCROLL_PAUSE_TIME = 0.5

# Get scroll height
    last_height = driver.execute_script("return document.body.scrollHeight")

    while True:
    # Scroll down to bottom
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    # Wait to load page
        time.sleep(SCROLL_PAUSE_TIME)
        click_load_more()

    # Calculate new scroll height and compare with last scroll height
        new_height = driver.execute_script("return document.body.scrollHeight")
        if new_height == last_height:
            break
        last_height = new_height

# Sort the movie data by movie ID
movie_data.sort(key=lambda x: int(x["MOVIE_ID"]))



# Define the CSV filename to save the data
csv_filename = "movies.csv"

# Write the extracted and sorted movie data to a CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["MOVIE_ID", "TITLE"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    writer.writerows(movie_data)

# Close the WebDriver
driver.quit()

print(f"Scraped {len(movie_data)} unique movie records and saved to {csv_filename}.")
