from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import csv

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the URL of the webpage to scrape movie data
movie_url = "https://www.themoviedb.org/movie/"

# Open the URL
driver.get(movie_url)

# Find all <a> elements with the specified format
movie_elements = driver.find_elements(By.CSS_SELECTOR, "a[href^='/movie/'][title]")

# Initialize a set to track unique movie IDs
unique_movie_ids = set()

# Initialize an empty list to store the movie data
movie_data = []

# Extract movie ID and title and add to the list (removing duplicates)
for element in movie_elements:
    href = element.get_attribute("href")
    title = element.get_attribute("title")
    movie_id = href.split("/movie/")[1]
    
    if movie_id not in unique_movie_ids:
        unique_movie_ids.add(movie_id)
        movie_data.append({"MOVIE_ID": movie_id, "TITLE": title})

# Sort the movie data by movie ID
movie_data.sort(key=lambda x: int(x["MOVIE_ID"]))

# Define the CSV filename to save the data
csv_filename = "movies.csv"

# Write the extracted and sorted movie data to a CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["MOVIE_ID", "TITLE"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    writer.writerows(movie_data)

# Close the WebDriver
driver.quit()

print(f"Scraped {len(movie_data)} unique movie records and saved to {csv_filename}.")
