# Read the text file into a list
with open('benjamin.txt', 'r') as file:
    lines = file.readlines()

# Use a set to remove duplicates and keep the order
unique_lines = list(dict.fromkeys(lines))

# Write the unique lines back to the file
with open('clean.txt', 'w') as file:
    file.writelines(unique_lines)
