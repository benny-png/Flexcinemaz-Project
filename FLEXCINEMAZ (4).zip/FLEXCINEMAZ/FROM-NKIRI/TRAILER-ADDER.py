import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
import time

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Open the CSV file for reading (replace with your TV series CSV file)
with open('NETNAIJAORGANIZEDSERIES_WITH_IDS.csv', 'r') as csvfile:
    csv_reader = csv.reader(csvfile)
    header = next(csv_reader)  # Skip the header row

    # Initialize series titles for series without YouTube URL
    series_titles_without_youtube = []

    # Initialize series_data list and a dictionary to store series IDs and trailer URLs
    series_data = []
    series_trailer_urls = {}

    # Iterate through the rows in the CSV
    for row in csv_reader:
        series_title, link, season, episode, series_id = row

        # If the series ID has already been scraped, use the stored trailer URL
        if series_id in series_trailer_urls:
            trailer_url = series_trailer_urls[series_id]
        else:
            # Function to scrape YouTube trailer data and add to series_data
            def scrape_youtube_trailer():
                youtube_url = "https://www.themoviedb.org/tv/" + series_id  # Adjust the URL for TV series
                driver.get(youtube_url)
                time.sleep(2)  # Add a delay to ensure the page loads properly

                try:
                    # Parse the page with BeautifulSoup
                    soup = BeautifulSoup(driver.page_source, 'html.parser')

                    # Find the first anchor element with the class "play_trailer"
                    trailer_element = soup.find('a', class_='no_click play_trailer')

                    # Extract the data-id attribute (YouTube trailer ID)
                    youtube_id = trailer_element['data-id']
                    return youtube_id
                except:
                    return None

            youtube_id = scrape_youtube_trailer()

            # If a YouTube ID is found, store it in the dictionary for reuse
            if youtube_id:
                trailer_url = f"https://www.youtube.com/watch?v={youtube_id}"
                series_trailer_urls[series_id] = trailer_url
                print(f"Scraped YouTube ID for '{series_title}': {youtube_id}")
            else:
                trailer_url = None
                # If no YouTube URL, add the series title to the series_titles_without_youtube list
                series_titles_without_youtube.append(series_title)

        series_data.append({
            "SERIES_TITLE": series_title,
            "LINK": link,
            "SEASON": season,
            "EPISODE": episode,
            "SERIES_ID": series_id,
            "YOUTUBE_URL": trailer_url
        })

# Define the new CSV filename to save the data
csv_filename = "NETNAIJAORGANIZEDSERIES_WITH_TRAILERS.csv"

# Write the extracted series data with YouTube trailers to a new CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["SERIES_TITLE", "LINK", "SEASON", "EPISODE", "SERIES_ID", "YOUTUBE_URL"]
    csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    csv_writer.writeheader()
    csv_writer.writerows(series_data)

# Define the text file name to save series titles without YouTube URL
text_filename_without_youtube = "SERIES_TITLES_WITHOUT_YOUTUBE.txt"

# Write the series titles without YouTube URL to a text file
with open(text_filename_without_youtube, "w") as textfile:
    for series_title in series_titles_without_youtube:
        textfile.write(series_title + "\n")

# Close the WebDriver
driver.quit()

print(f"Scraped YouTube trailer data for {len(series_data)} TV series and saved to {csv_filename}.")
print(f"Saved {len(series_titles_without_youtube)} TV series titles without YouTube URL to {text_filename_without_youtube}.")
