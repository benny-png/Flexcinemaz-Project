import openpyxl

# Load the Excel file
workbook = openpyxl.load_workbook('CoICT Google Scholar.xlsx')

# Select the specific sheet
sheet = workbook['CoICT']  # Replace 'CoICT' with your actual sheet name

i= 0
# Iterate through each row and check the status column
for row in sheet.iter_rows(min_row=2, min_col=1):

    status_cell = row[5]  # Assuming the status column is at index 5 (column F)

    if status_cell.value == 'Registered' and status_cell.hyperlink:
        i += 1
        hyperlink_address = status_cell.hyperlink.target
        print("Found link:", hyperlink_address)


print(f"Registered are {i}")
# Close the workbook
workbook.close()
