import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# Configure Chrome options for the website
brave_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
options = Options()
options.binary_location = brave_path
# options.add_argument("user-data-dir=D:\selenium")
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Open the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Navigate to the desired URL
url = "https://scholar.google.com/citations?hl=en&user=iR8mYs0AAAAJ&view_op=list_works&sortby=pubdate"
driver.get(url)

# Find the name element
name_element = driver.find_element(By.XPATH, '//div[@id="gsc_prf_in"]')
name = name_element.text

# Find all <a> tags with class 'gsc_a_at'
elements = driver.find_elements(By.XPATH, '//a[@class="gsc_a_at"]')

# Find all <span> tags with class 'gsc_a_h gsc_a_hc gs_ibl'
span_elements = driver.find_elements(By.XPATH, '//span[@class="gsc_a_h gsc_a_hc gs_ibl"]')

# Specify the title you want to stop at
stop_title = "Effective path-loss compensation model based on multipath exploitation for through-the-wall radar imaging"

# Flag to indicate whether stop title is found
stop_found = False

# Initialize an empty list to store paper details
paper_details = []

# Iterate through the elements
for i, element in enumerate(elements):
    if element.text == stop_title:
        stop_found = True
        break  # Stop the loop if the stop title is found
    # Get the corresponding <span> element for year of publication
    year_span = span_elements[i] if i < len(span_elements) else None
    year_of_publication = year_span.text if year_span else "N/A"

    # Extract title and link information
    title = element.text
    link = element.get_attribute('href')

    # Append paper details to the list
    paper_details.append({'NAME': name, 'TITLE': title, 'YEAR': year_of_publication , 'LINK': link})

# Close the WebDriver
driver.quit()

# Save the paper details to a CSV file
csv_file = "research_papers.csv"
with open(csv_file, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.DictWriter(file, fieldnames=['NAME', 'TITLE', 'LINK', 'YEAR'])
    writer.writeheader()  # Write the header row
    writer.writerows(paper_details)  # Write the paper details

print(f"Research paper details saved to {csv_file}")
