import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
import time

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Open the CSV file for reading
with open('NETNAIJAORGANIZEDMOVIES_WITH_IDS.csv', 'r') as csvfile:
    csv_reader = csv.reader(csvfile)
    header = next(csv_reader)  # Skip the header row

    # Initialize movie_data list
    movie_data = []

    # Iterate through the rows in the CSV
    for row in csv_reader:
        movie_title, year, movie_link, movie_id = row

        # Function to scrape YouTube trailer data and add to movie_data
        def scrape_youtube_trailer():
            youtube_url = "https://www.themoviedb.org/movie/" + movie_id
            driver.get(youtube_url)
            time.sleep(2)  # Add a delay to ensure the page loads properly

            try:
                # Parse the page with BeautifulSoup
                soup = BeautifulSoup(driver.page_source, 'html.parser')

                # Find the first anchor element with the class "play_trailer"
                trailer_element = soup.find('a', class_='no_click play_trailer')

                # Extract the data-id attribute (YouTube trailer ID)
                youtube_id = trailer_element['data-id']
                return youtube_id
            except:
                return None

        youtube_id = scrape_youtube_trailer()
        if youtube_id:
            movie_data.append({
                "MOVIE_TITLE": movie_title,
                "YEAR": year,
                "MOVIE_LINK": movie_link,
                "MOVIE_ID": movie_id,
                "YOUTUBE_URL": f"https://www.youtube.com/watch?v={youtube_id}"
            })
            print(f"Scraped YouTube ID for '{movie_title}': {youtube_id}")

# Define the new CSV filename to save the data
csv_filename = "NETNAIJAORGANIZEDMOVIES_WITH_TRAILERS.csv"

# Write the extracted movie data with YouTube trailers to a new CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["MOVIE_TITLE", "YEAR", "MOVIE_LINK", "MOVIE_ID", "YOUTUBE_URL"]
    csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    csv_writer.writeheader()
    csv_writer.writerows(movie_data)

# Close the WebDriver
driver.quit()

print(f"Scraped YouTube trailer data for {len(movie_data)} movies and saved to {csv_filename}.")
