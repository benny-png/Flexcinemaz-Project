import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

# Configure Chrome options for the website
brave_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
options = Options()
options.binary_location = brave_path
#options.add_argument("user-data-dir=D:\selenium")
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
driver.maximize_window()

# Define the URL of the webpage to open
flexcinemaz_url = "https://flexcinemaz.com/user/login"

driver.get('https://flexcinemaz.com/user/login')

input_element = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/input[1]')
# Write "Server 1" to the input element
input_element.clear()  # Clear any existing text
input_element.send_keys("benjamin@flexcinemaz.com")

input_element = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/input[2]')
# Write "Server 1" to the input element
input_element.clear()  # Clear any existing text
input_element.send_keys("benjamin@")


wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed
next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/div[3]/button')))
next_button.click()

driver.get('https://flexcinemaz.com/admin/videos_add/')

#driver.get('https://flexcinemaz.com/admin/videos_add/')

# Open the CSV file for reading
with open('NETNAIJAORGANIZEDMOVIES_WITH_TRAILERS.csv', 'r') as csvfile:
    csv_reader = csv.DictReader(csvfile)

    # Iterate through the rows in the CSV
    #driver.get(flexcinemaz_url)
    i = 0
    for row in csv_reader:
        movie_id = row['MOVIE_ID']
        

        # Open the URL
        if i == 0:
           pass
           #input("Log in manually, then press Enter to continue...")

        # Find and populate the 'imdb_id' input field
        imdb_id_input = driver.find_element(By.ID,"imdb_id")
        imdb_id_input.clear()
        imdb_id_input.send_keys(movie_id)

        # Find and click the 'FETCH' button
        fetch_button = driver.find_element(By.ID,"import_btn")
        fetch_button.click()

        # Wait for a moment to allow the page to load
        time.sleep(3) # You can adjust the waiting time as needed


        checkbox = driver.find_element(By.XPATH, '//div[@class="toggle"]/label[input[@type="checkbox" and @name="enable_download"]]')
        if not checkbox.is_selected():
                # If it's not checked, check it
                checkbox.click()

        time.sleep(5)
        create_button = driver.find_element(By.XPATH, '/html/body/main/form/div/div[2]/div/div[2]/div[9]/div/button')
        driver.execute_script("arguments[0].click();", create_button)


        try: #check if the rows MOVIE ID BRINGS ERRORS IN THE 'THIS REQUIRED FIELD'
           wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed
           next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
           next_button.click()
        except:
            continue

        input_element = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[1]/div[1]/div[2]/form/div[1]/input')
        # Write "Server 1" to the input element
        input_element.clear()  # Clear any existing text
        input_element.send_keys("Server 1")

        input_element2 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[1]/div[1]/div[2]/form/div[2]/input')
        # Write "1" to input_element2
        input_element2.clear()  # Clear any existing text
        input_element2.send_keys("1")   

        select_element = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[1]/div[1]/div[2]/form/div[3]/select')
        # Create a Select object
        select = Select(select_element)
        # Select "Youtube" from the dropdown by its value
        select.select_by_value("youtube")

        input_element3 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[1]/div[1]/div[2]/form/div[4]/input')

        # Assuming you have the corresponding "movie_link" value from your CSV
        youtube_link = row['YOUTUBE_URL']# Replace with the actual value from your CSV

        # Write the "movie_link" value to the input element
        input_element3.clear()  # Clear any existing text
        input_element3.send_keys(youtube_link)

        add_button = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[1]/div[1]/div[2]/form/div[6]/button')
        add_button.click()
        time.sleep(3)

        wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed
        next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
        next_button.click()
        

        input_element4 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[2]/div[1]/div[2]/div/form/div[1]/input')
        # Write "Drive" to input_element4
        input_element4.clear()  # Clear any existing text
        input_element4.send_keys("Drive")

        input_element5 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[2]/div[1]/div[2]/div/form/div[2]/input')
        # Write "480p" to input5
        input_element5.clear()  # Clear any existing text
        input_element5.send_keys("480p")

        input_element6 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[2]/div[1]/div[2]/div/form/div[3]/input')
        # Write "480p" to input5
        input_element6.clear()  # Clear any existing text
        input_element6.send_keys("300MB")


        input_element7 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[2]/div[1]/div[2]/div/form/div[4]/input')
        movie_link = row['MOVIE_LINK']
        # Write the "movie_link" from the CSV row to input_element6
        input_element7.clear()  # Clear any existing text
        input_element7.send_keys(movie_link)


        select_element2 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[2]/div[1]/div[2]/div/form/div[5]/select')
        # Create a Select object
        select = Select(select_element2)
        # Select "In app download" from the dropdown by its visible text
        select.select_by_visible_text("In app download")
        time.sleep(1)

    
        button_element2 = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[2]/div[2]/div[1]/div[2]/div/form/button')
        button_element2.click()
        time.sleep(3)

        wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed
        next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
        next_button.click()

        driver.get('https://flexcinemaz.com/admin/videos_add/')
        i += 1
        
        wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed
        next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
        next_button.click()
        
# Close the WebDriver
driver.quit()

print("Completed the task.")
