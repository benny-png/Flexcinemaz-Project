import re
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# Configure Chrome options for the website
brave_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
options = Options()
options.binary_location = brave_path
# options.add_argument("user-data-dir=D:\selenium")
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Navigate to the desired URL
global url
url = "https://scholar.google.com/citations?hl=en&user=iR8mYs0AAAAJ&view_op=list_works&sortby=pubdate"
driver.get(url)

# Find all <a> tags with class 'gsc_a_at'
elements = driver.find_elements(By.XPATH, '//a[@class="gsc_a_at"]')

# Find all <span> tags with class 'gsc_a_h gsc_a_hc gs_ibl'
span_elements = driver.find_elements(By.XPATH, '//span[@class="gsc_a_h gsc_a_hc gs_ibl"]')

# Specify the title you want to stop at
stop_title = "Effective path-loss compensation model based on multipath exploitation for through-the-wall radar imaging"

# Flag to indicate whether stop title is found
stop_found = False

# Function to process matched authors
def process_authors(match):
    # Split the first group (\1) into individual letters and add a period after each letter
    first_group = match.group(1)
    processed_first_group = '. '.join(first_group)
    return f"{match.group(2)}, {processed_first_group}."

# Function to split other_details_text
def split_other_details(other_details):
    # Add a comma after each space if it's followed by a digit
    split_text = re.sub(r'\s(?=\d)', ', ', other_details)
    # Remove extra spaces after comma
    split_text = re.sub(r',\s+', ', ', split_text)
    # Remove consecutive commas
    split_text = re.sub(r',+', ',', split_text)
    return split_text

def add_ampersand(formatted_authors):
    # Split the string into individual names
    authors = formatted_authors.split(", ")
    # Insert "&" before the last name
    authors[-2] = "& " + authors[-2]
    # Join the names back into a string
    formatted_authors_with_ampersand = ", ".join(authors)
    return formatted_authors_with_ampersand


# Function to get text from specific elements
def get_text_from_element(xpath):
    try:
        element = driver.find_element(By.XPATH, xpath)
        return element.text
    except:
        return ""

# Print the formatted authors, other details, and year of publication of all found elements
for i, element in enumerate(elements):
    if element.text == stop_title:
        stop_found = True
        #break

    # Get the corresponding <span> element for year of publication
    year_span = span_elements[i] if i < len(span_elements) else None
    year_of_publication = year_span.text if year_span else "N/A"

    authors_div = element.find_element(By.XPATH, './following-sibling::div')
    authors_text = authors_div.text

    # Format authors using regular expressions and a function
    formatted_authors = re.sub(r'([\w]+)\s+([\w]+)', process_authors, authors_text)
    #formatted_authors = add_ampersand(formatted_authors)

    # Get the next div after the current one for other details
    other_details_div = authors_div.find_element(By.XPATH, './following-sibling::div')
    other_details_text = other_details_div.text

    # Split other_details_text
    split_other_details_text = split_other_details(other_details_text)



    print(f"{formatted_authors} ({year_of_publication}). {element.text} {split_other_details_text}." )
    #print(f"{authors_text}" )

# Close the WebDriver
driver.quit()
