import csv
import re
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

# Configure Chrome options for the website
brave_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
options = Options()
options.binary_location = brave_path
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the base URL of the webpage to scrape movie data
base_url = "https://nkiri.com"

# Function to extract and save movie data to a CSV file
def extract_and_save_movie_data(movie_names):
    movie_data = []  # Use a list to preserve order

    for movie_name in movie_names:
        search_url = f"{base_url}/?s={movie_name}&post_type=post"
        driver.get(search_url)

        # Find the first 'a' element with the specified attributes
        try:
            first_movie_element = driver.find_element(By.XPATH,
                                                      '//a[@rel="bookmark"]')
        except:
            continue

        title = first_movie_element.text
        link = first_movie_element.get_attribute('href')

        # Extract the year from the title
        match = re.search(r'^(.+?)\s+S(\d+)', title)
        if match:
            title = match.group(1).strip()
            season = match.group(2).strip()

        movie_data.append({"Title": title, "Season": season, "Link": link})

    # Save the movie data in a CSV file
    csv_filename = "movie_data_search.csv"
    with open(csv_filename, 'w', newline='') as csvfile:
        fieldnames = ["Title", "Season", "Link"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        writer.writerows(movie_data)

    print(f"Movie data extracted and saved to {csv_filename}")

# Read movie names from the file
with open(r'C:\Users\benny\CLEAN-SERIES-FOR-UPLOAD.txt', 'r') as movie_file:
    movie_names = [line.strip() for line in movie_file.readlines()]

# Call the function to extract and save movie data
extract_and_save_movie_data(movie_names)

# Close the WebDriver
driver.quit()
