import csv
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
import time

# Configure Chrome options for the website
brave_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
options = Options()
options.binary_location = brave_path
#options.add_argument("user-data-dir=D:\selenium")
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the base URL of the webpage to scrape movie data
base_url = "https://www.watchfever.xyz/tv-series"

# Function to extract and save movie titles to a CSV file
def extract_and_save_movie_titles():
    page_number = 1
    movie_titles = []  # Use a list to preserve order

    while page_number < 5:  # Scrape up to 10 pages
        page_url = base_url if page_number == 1 else f"{base_url}/?page={page_number}"
        driver.get(page_url)
        
        # Scroll down to load all elements
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(2)  # Add a delay to allow content to load
        
        # Find all 'a' elements with the specified attributes
        movie_elements = driver.find_elements(By.XPATH, '//a[starts-with(@href, "/tv-series")]')

        for element in movie_elements:
            title = element.text
            
            # Remove text within brackets
            title = re.sub(r'\s*\([^)]*\)', '', title)
            
            # Append non-empty titles to the list
            if title.strip():
                movie_titles.append(title.strip())

        # Print progress
        print(f"Page {page_number} scraped.")

        page_number += 1

    # Remove duplicates while preserving order
    movie_titles = list(dict.fromkeys(movie_titles))
    
    # Save the movie titles in a CSV file
    csv_filename = "movie_titles.csv"
    with open(csv_filename, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["MOVIE_TITLE"])  # Write header
        writer.writerows([[title] for title in movie_titles])

    print(f"Movie titles extracted and saved to {csv_filename}")

# Call the function to extract and save movie titles
extract_and_save_movie_titles()

# Close the WebDriver
driver.quit()
