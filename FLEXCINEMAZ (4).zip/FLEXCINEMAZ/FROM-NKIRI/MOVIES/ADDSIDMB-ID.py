import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the URL of the webpage to search for movies by title
search_url = "https://www.themoviedb.org/search?query="

# Open the CSV file for reading
with open('NETNAIJAORGANIZEDMOVIES.csv', 'r') as csvfile:
    csv_reader = csv.reader(csvfile)
    header = next(csv_reader)  # Skip the header row

    # Initialize movie_data list
    movie_data = []
    seen_titles = set()  # Keep track of seen movie titles

    # Iterate through the rows in the CSV
    for row in csv_reader:
        movie_title, year, movie_url = row

        # Check if the movie title has already been seen
        if movie_title in seen_titles:
            print(f"Duplicate movie title found: '{movie_title}', skipping...")
            continue

        # Function to search for movie data and extract movie IDs with a year filter
        def search_and_extract_movie_id():
            search_query = movie_title.replace(' ', '%20')
            search_query_url = f"{search_url}{search_query} y:{year}"

            # Open the search URL
            driver.get(search_query_url)

            try:
                # Parse the page with BeautifulSoup
                soup = BeautifulSoup(driver.page_source, 'html.parser')

                # Find the div with class "search_results movie"
                results_div = soup.find('div', class_='search_results movie')

                if results_div:
                    # Find the first anchor element containing "/movie/" in its href
                    first_result = results_div.find('a', href=lambda href: href and '/movie/' in href)

                    if first_result:
                        # Extract the movie ID from the 'href' attribute
                        movie_id = first_result['href'].split("/movie/")[1]
                        return movie_id

                return None
            except:
                return None

        movie_id = search_and_extract_movie_id()
        if movie_id:
            seen_titles.add(movie_title)  # Add movie title to the set
            movie_data.append({
                "MOVIE_TITLE": movie_title,
                "YEAR": year,
                "MOVIE_LINK": movie_url,
                "MOVIE_ID": movie_id
            })
            print(f"Scraped Movie ID for '{movie_title}': {movie_id}")

# Define the new CSV filename to save the data
csv_filename = "NETNAIJAORGANIZEDMOVIES_WITH_IDS.csv"

# Write the extracted movie data to a new CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["MOVIE_TITLE", "YEAR", "MOVIE_LINK", "MOVIE_ID"]
    csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    csv_writer.writeheader()
    csv_writer.writerows(movie_data)

# Close the WebDriver
driver.quit()

print(f"Scraped {len(movie_data)} movie records and saved to {csv_filename}.")
