import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the base URL of the webpage to scrape movie data
base_url = "https://nkiri.com/category/international"

# Function to extract and save movie data to a CSV file
def extract_and_save_movie_data(movie_names):
    movie_data = []  # Use a list to preserve order

    for movie_name in movie_names:
        search_url = f"{base_url}/?s={movie_name}&post_type=post"
        driver.get(search_url)

        try:
            # Find the first 'a' element with the specified attributes
            first_movie_element = driver.find_element(By.XPATH, '//a[@rel="bookmark"]')

            title = first_movie_element.text
            link = first_movie_element.get_attribute('href')
            
            # Extract the year from the title
            year = title.split(" | ")[0].split(" (")[-1].rstrip(")")
            title = title.split(" (")[0]
            
            movie_data.append({"Title": title, "Year": year, "Link": link})
        except NoSuchElementException:
            print(f"Movie '{movie_name}' not found. Skipping.")

    if movie_data:
        # Save the movie data in a CSV file
        csv_filename = "movie_data_search.csv"
        with open(csv_filename, 'w', newline='') as csvfile:
            fieldnames = ["Title", "Year", "Link"]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            writer.writeheader()
            writer.writerows(movie_data)

        print(f"Movie data extracted and saved to {csv_filename}")
    else:
        print("No movies found.")

# Read movie names from the file
with open('Movie_errors.txt', 'r') as movie_file:
    movie_names = [line.strip() for line in movie_file.readlines()]

# Call the function to extract and save movie data
extract_and_save_movie_data(movie_names)

# Close the WebDriver
driver.quit()
