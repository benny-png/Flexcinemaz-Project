import csv

# Read the CSV data into a list of dictionaries
data = []
with open('NETNAIJAORGANIZEDSERIES_WITH_TRAILERS.csv', 'r') as csvfile:
    csv_reader = csv.DictReader(csvfile)
    for row in csv_reader:
        data.append(row)

# Create a dictionary to store unique SERIES_ID for each series title and their YOUTUBE_URL
series_info = {}

# Iterate through the data to assign unique SERIES_ID and YOUTUBE_URL to each series
for row in data:
    series_title = row['SERIES_TITLE']
    series_id = row.get('SERIES_ID', '')  # Use a default value (empty string) if 'SERIES_ID' is not present
    youtube_url = row.get('YOUTUBE_URL', '')  # Use a default value (empty string) if 'YOUTUBE_URL' is not present
    series_info[series_title] = {'SERIES_ID': series_id, 'YOUTUBE_URL': youtube_url}

# Group the data by series title
series_data = {}
for row in data:
    series_title = row['SERIES_TITLE']
    season = row['SEASON']
    episode = row['EPISODE']
    
    if series_title not in series_data:
        series_data[series_title] = {'SEASONS': {}, 'SERIES_ID': series_info[series_title]['SERIES_ID'], 'YOUTUBE_URL': series_info[series_title]['YOUTUBE_URL']}
        
    if season not in series_data[series_title]['SEASONS']:
        series_data[series_title]['SEASONS'][season] = []
    
    series_data[series_title]['SEASONS'][season].append(episode)

# Create a new list with rows for each series title, combined seasons, combined episode counts, SERIES_ID, and YOUTUBE_URL
results = []
for series_title, series_info in series_data.items():
    seasons_and_episodes = series_info['SEASONS']
    seasons = ', '.join([season for season in seasons_and_episodes])
    episode_counts = ', '.join([str(len(episodes)) for episodes in seasons_and_episodes.values()])
    series_id = series_info['SERIES_ID']
    youtube_url = series_info['YOUTUBE_URL']
    results.append({'SERIES_TITLE': series_title, 'SEASONS': seasons, 'NUMBER_OF_EPISODES': episode_counts, 'SERIES_ID': series_id, 'YOUTUBE_URL': youtube_url})

# Now, 'results' contains rows for each series title with combined seasons, combined episode counts, unique SERIES_ID, and YOUTUBE_URL

# You can then save the result to a new CSV file if needed
with open('organized_series_seasons.csv', 'w', newline='') as csvfile:
    fieldnames = ['SERIES_TITLE', 'SEASONS', 'NUMBER_OF_EPISODES', 'SERIES_ID', 'YOUTUBE_URL']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(results)
