import csv

# Read the CSV data into a list of dictionaries
data = []
with open('NETNAIJAORGANIZEDSERIES_WITH_TRAILERS.csv', 'r') as csvfile:
    csv_reader = csv.DictReader(csvfile)
    for row in csv_reader:
        data.append(row)

# Sort the data by series title in alphabetical order
data.sort(key=lambda x: x['SERIES_TITLE'])

# Group the data by series title
series_data = {}
for row in data:
    series_title = row['SERIES_TITLE']
    if series_title not in series_data:
        series_data[series_title] = []
    series_data[series_title].append(row)

# Sort the data for each series title by season and episode
for series_title, episodes in series_data.items():
    episodes.sort(key=lambda x: (int(x['SEASON']), int(x['EPISODE'])))

# Now, series_data contains the organized data grouped by series title with titles in alphabetical order

# You can then save the organized data back to a new CSV file if needed
# You can use the csv.DictWriter to write the data to a new CSV file
num_unique_titles = len(series_data)
print(f"Number of unique series titles: {num_unique_titles}")


# Example:
with open('NETNAIJAORGANIZEDSERIES_WITH_TRAILERS.csv', 'w', newline='') as csvfile:
    fieldnames = data[0].keys()
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for series_title, episodes in series_data.items():
        writer.writerows(episodes)
