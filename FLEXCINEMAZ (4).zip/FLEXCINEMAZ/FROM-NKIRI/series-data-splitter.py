import csv

# Load your series data from the original CSV file
series_data = []

with open('series_data.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        series_data.append(row)

# Define the number of groups
num_groups = 5

# Calculate the number of URLs in each group
urls_per_group = len(series_data) // num_groups

# Split the series data into groups
data_groups = [series_data[i:i + urls_per_group] for i in range(0, len(series_data), urls_per_group)]

# Save each group into a separate CSV file
for i, group in enumerate(data_groups, start=1):
    output_filename = f'group_{i}.csv'
    with open(output_filename, 'w', newline='') as outfile:
        fieldnames = ["series_title", "season", "link"]
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(group)
    print(f'Saved {len(group)} URLs to {output_filename}')
