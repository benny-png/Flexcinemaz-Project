import pandas as pd

# Read the CSV file into a DataFrame with the specified encoding
df = pd.read_csv('NKIRISERIES.csv', encoding='latin-1')

# Initialize a set to keep track of processed links
processed_links = set()

# Create a new DataFrame to store the unique rows
unique_df = pd.DataFrame(columns=df.columns)

# Iterate through the DataFrame to remove duplicates and print progress
for index, row in df.iterrows():
    link = row['LINK']
    if link not in processed_links:
        # Convert non-NaN values in the "SEASON" and "EPISODE" columns to integers
        if not pd.isna(row['SEASON']):
            row['SEASON'] = int(row['SEASON'])
        if not pd.isna(row['EPISODE']):
            row['EPISODE'] = int(row['EPISODE'])
        
        # Add the row to the unique DataFrame
        unique_df = unique_df.append(row, ignore_index=True)
        processed_links.add(link)
    print(f"Processed {len(processed_links)} unique links.")

# Write the cleaned DataFrame back to a CSV file
unique_df.to_csv('NKIRISERIES-clean.csv', index=False)
