import pandas as pd

# Read the CSV file into a DataFrame
df = pd.read_csv("SERIES_TITLE_WITHOUT_YOUTUBE.csv")

# Remove duplicates
df = df.drop_duplicates()

# Save the DataFrame back to a CSV file
df.to_csv("your_output_file.csv", index=False)

print("Duplicates removed. Unique rows saved to your_output_file.csv")
