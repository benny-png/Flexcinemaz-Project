import re
import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import concurrent.futures

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

def extract_movie_data(group_rows, movie_data):
    seen_movie_links = set()
    # Initialize a new WebDriver instance
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    for row in group_rows:
        link = row["link"]
        title = row["series_title"]  # Get the title from the row
        print(f"Scraping: {link}")

        # Open the URL
        driver.get(link)
        x = 1
        while x == 1:
            movie_elements = driver.find_elements(By.CSS_SELECTOR, "a[href^='https://wetafiles.com/'], a[href^='https://downloadwella.com/']")
            print('im here')
            if not movie_elements:
                break  # Exit the loop if no more elements are found
            for element in movie_elements:
                href = element.get_attribute("href")
                if href in seen_movie_links:
                    x = 0
                # Extract season and episode from the scraped link
                season_match = re.search(r's(\d+)e(\d+)', href, re.IGNORECASE)
                if season_match:
                    season = season_match.group(1)
                    episode = season_match.group(2)
                else:
                    season = None
                    episode = None

                # Skip duplicates
                seen_movie_links.add(href)
                movie_data.append({"MOVIE_TITLE": title, "LINK": href, "SEASON": season, "EPISODE": episode})
                print(f"Scraped: {title} - {href} - S{season}E{episode}")
        print(f"Finished scraping: {link}")

    # Close the WebDriver
    driver.quit()

def process_group(group_csv):
    movie_data = []  # Initialize a list to store the movie data
    group_rows = []  # Initialize a list to store the rows for this group

    # Read the series data from the group CSV file
    with open(group_csv, 'r') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            group_rows.append(row)  # Add rows to the group

    # Extract movie data for this group
    extract_movie_data(group_rows, movie_data)  # Pass the rows and movie_data

    return movie_data  # Return the movie data extracted from this group

# List of group CSV files (e.g., group_1.csv, group_2.csv, etc.)
group_csv_files = ["group_1.csv", "group_2.csv", "group_3.csv", "group_4.csv", "group_5.csv"]

# Initialize a ThreadPoolExecutor
with concurrent.futures.ThreadPoolExecutor() as executor:
    # Process each group concurrently and get the movie data
    movie_data_list = list(executor.map(process_group, group_csv_files))

# Combine the results from all groups into a single list
combined_movie_data = [item for sublist in movie_data_list for item in sublist]

# Define the CSV filename to save the data
csv_filename = "NKIRISERIES.csv"

# Write the extracted movie data to a single CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["MOVIE_TITLE", "LINK", "SEASON", "EPISODE"]  # Add "SEASON" and "EPISODE"
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(combined_movie_data)

print(f"Scraped {len(combined_movie_data)} unique movie records and saved to {csv_filename}.")
