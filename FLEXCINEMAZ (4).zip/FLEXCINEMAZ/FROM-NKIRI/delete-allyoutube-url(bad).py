import csv

# Open the original CSV file for reading
with open('NETNAIJAORGANIZEDSERIES_WITH_TRAILERS.csv', 'r', newline='') as infile:
    reader = csv.DictReader(infile)

    # Create a list of field names excluding 'YOUTUBE_URL'
    fieldnames = [field for field in reader.fieldnames if field != 'YOUTUBE_URL']

    # Open a new CSV file for writing without 'YOUTUBE_URL'
    with open('NETNAIJAORGANIZEDSERIES_WITH_TRAILERS_no_url.csv', 'w', newline='') as outfile:
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)
        writer.writeheader()  # Write the header to the new file

        # Copy rows from the original file to the new file, excluding 'YOUTUBE_URL'
        for row in reader:
            del row['YOUTUBE_URL']  # Remove the 'YOUTUBE_URL' column from the row
            writer.writerow(row)

print("YOUTUBE_URL column removed and saved to NETNAIJAORGANIZEDSERIES_WITH_TRAILERS_no_url.csv")
