import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the URL of the webpage to search for TV series by title
search_url = "https://www.themoviedb.org/search/tv?query="

# Open the CSV file for reading
with open('NETNAIJAORGANIZEDMOVIES.csv', 'r') as csvfile:
    csv_reader = csv.reader(csvfile)
    header = next(csv_reader)  # Skip the header row

    # Initialize series_data list to store series data
    series_data = []
    unique_series_titles = set()  # To store unique series titles

    # Iterate through the rows in the CSV and gather unique series titles
    for row in csv_reader:
        series_title, link, season, episode = row
        if series_title not in unique_series_titles:
            unique_series_titles.add(series_title)

    print(f"Found {len(unique_series_titles)} unique series titles to fetch series IDs for.")

    # Function to search for series data and extract series IDs
    def search_and_extract_series_ids(title_set):
        series_id_dict = {}  # To store series IDs for unique series titles
        for title in title_set:
            search_query = title.replace(' ', '%20')
            search_query_url = f"{search_url}{search_query}"

            # Open the search URL
            driver.get(search_query_url)
            print(f"Fetching Series ID for '{title}'...")

            try:
                # Parse the page with BeautifulSoup
                soup = BeautifulSoup(driver.page_source, 'html.parser')

                # Find the div with class "search_results tv"
                results_div = soup.find('div', class_='search_results tv')

                if results_div:
                    # Find the first anchor element containing "/tv/" in its href
                    first_result = results_div.find('a', href=lambda href: href and '/tv/' in href)

                    if first_result:
                        # Extract the series ID from the 'href' attribute
                        series_id = first_result['href'].split("/tv/")[1]
                        series_id_dict[title] = series_id
                        print(f"Scraped Series ID for '{title}': {series_id}")

            except:
                print(f"Failed to fetch Series ID for '{title}'")

        return series_id_dict

    series_id_dict = search_and_extract_series_ids(unique_series_titles)

    # Iterate through the CSV data and populate the series_data list
    csvfile.seek(0)  # Reset the file pointer
    next(csv_reader)  # Skip the header row again
    for row in csv_reader:
        series_title, link, season, episode = row
        series_id = series_id_dict.get(series_title, "")
        series_data.append({
            "SERIES_TITLE": series_title,
            "LINK": link,
            "SEASON": season,
            "EPISODE": episode,
            "SERIES_ID": series_id
        })

# Define the new CSV filename to save the data
csv_filename = "NETNAIJAORGANIZEDSERIES_WITH_IDS.csv"

# Write the extracted series data to a new CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["SERIES_TITLE", "LINK", "SEASON", "EPISODE", "SERIES_ID"]
    csv_writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    csv_writer.writeheader()
    # Write data from the list to the CSV
    csv_writer.writerows(series_data)

# Close the WebDriver
driver.quit()

print(f"Scraped {len(series_data)} series records and saved to {csv_filename}.")
