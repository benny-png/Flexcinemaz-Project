import random
import time
import pyserial
i = 1
while True:
    # Print "Merry Christmas"
    print("Merry Christmas 🎅 🎄✨")

    # Generate a CONTCT number with country code +255

    random_number = "+255" + str(random.randint(100000000, 999999999))

    # Print the random number
    print(f"MY CONTACT Number {i} :", random_number)
    i += 1
    # Add a delay of 1 second before the next iteration
    time.sleep(1)
