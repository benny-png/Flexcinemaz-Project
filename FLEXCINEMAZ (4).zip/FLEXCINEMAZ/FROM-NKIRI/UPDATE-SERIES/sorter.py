import csv

# Read series titles from all_series_names.txt into a set
with open(r'D:\Downloads\FLEXCINEMAZ\FROM-NKIRI\all_series_names.txt', 'r', encoding='utf-8') as txt:
    excluded_series = {line.strip() for line in txt.readlines()}

clean_series = []

# Read series_data.csv
with open(r'C:\Users\benny\movie_titles.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)

    # Iterate over each row in series_data.csv
    for csv_row in reader:
        movie_name = csv_row['series_title']

        # If the series_title is not in all_series_names.txt, add it to clean_series
        if movie_name not in excluded_series:
            clean_series.append(csv_row)

# Write the clean series to CLEAN-SERIES-FOR-UPLOAD.txt
with open('CLEAN-SERIES-FOR-UPLOAD.txt', 'w', encoding='utf-8') as clean:
    for series in clean_series:
        clean.write(f"{series['series_title']}\n")

print('Done task')
