import csv
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

# Configure Chrome options for the website
brave_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
options = Options()
options.binary_location = brave_path
#options.add_argument("user-data-dir=D:\selenium")
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')


# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

driver.maximize_window()

# Define the URL of the webpage to open
flexcinemaz_url = "https://flexcinemaz.com/user/login"

driver.get('https://flexcinemaz.com/user/login')

input_element = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/input[1]')
# Write "Server 1" to the input element
input_element.clear()  # Clear any existing text
input_element.send_keys("benjamin@flexcinemaz.com")

input_element = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/input[2]')
# Write "Server 1" to the input element
input_element.clear()  # Clear any existing text
input_element.send_keys("benjamin@")


wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/div[3]/button')))
next_button.click()

driver.get('https://flexcinemaz.com/admin/tvseries_add/')

# Open the CSV file for reading
    
asian_anime = []

with open('organized_series_seasons.csv', 'r') as csvfile:
    
    csv_reader = csv.DictReader(csvfile)

    # Iterate through the rows in the CSV
    i = 0
    
    for row in csv_reader:
        row_series_count = 0 #number of seasons
        movie_id = row['SERIES_ID']
        series_title = row['SERIES_TITLE']
        seasons = row['SEASONS']
        youtube_url = row['YOUTUBE_URL']
        seasons_list = []
        episode_numbers_list = []
        if ',' in seasons:
            seasons = [int(season.strip()) for season in seasons.split(',')]
        else:
            seasons = [int(seasons.strip())]

        seasons_list.extend(seasons)
        episode_numbers = row['NUMBER_OF_EPISODES']
        
        if ',' in episode_numbers:
             episode_numbers = [int(episode.strip()) for episode in episode_numbers.split(',')]
        else:
            episode_numbers = [int(episode_numbers.strip())]
            
        episode_numbers_list.extend(episode_numbers)

        


        # Open the URL
        if i == 0:
           pass

        # Find and populate the 'imdb_id' input field
        imdb_id_input = driver.find_element(By.ID,"imdb_id")
        imdb_id_input.clear()
        imdb_id_input.send_keys(movie_id)

        # Find and click the 'FETCH' button
        fetch_button = driver.find_element(By.ID,"import_btn")
        fetch_button.click()

        # Wait for a moment to allow the page to load
        time.sleep(10) # You can adjust the waiting time as needed

        # Extract the image link
        # 
        thumb_link_input = driver.find_element(By.NAME, "thumb_link")

        thumb_link = WebDriverWait(driver, 100).until(
            EC.visibility_of(thumb_link_input)
        ).get_attribute("value")

        # Download the image
        response = requests.get(thumb_link)
        if response.status_code == 200:
            image_filename = f"{movie_id}.jpg"  # You can change the filename if needed
            with open(image_filename, 'wb') as image_file:
                image_file.write(response.content)
            print(f"Downloaded image for {movie_id} as {image_filename}")
        else:
            print(f"Failed to download image for {movie_id}")


        checkbox = driver.find_element(By.XPATH, '//div[@class="toggle"]/label[input[@type="checkbox" and @name="enable_download"]]')
        if not checkbox.is_selected():
                # If it's not checked, check it
                checkbox.click()

        element = driver.find_element(By.XPATH, '/html/body/main/form/div/div[1]/div/div[2]/div[17]/input')
        element.clear()
        print(youtube_url)
        element.send_keys(youtube_url)

        time.sleep(5)
        create_button = driver.find_element(By.XPATH, '/html/body/main/form/div/div[2]/div/div[2]/div[9]/div/button')
        driver.execute_script("arguments[0].click();", create_button)
        try:
           wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
           next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
           next_button.click()
        except:
            driver.get('https://flexcinemaz.com/admin/tvseries_add/')
            
            wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
            ok_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
            ok_button.click()
            asian_anime.append(series_title)
            continue
            


    
        for season, number_of_episodes in zip(seasons_list, episode_numbers_list):
    
    
            add_season_button = driver.find_element(By.XPATH, '//button[@data-toggle="modal" and @data-target="#mymodal" and contains(@class, "btn-primary")]')
            add_season_button.click()
                        
            seasons_name_input = wait.until(EC.visibility_of_element_located((By.NAME, "seasons_name")))

            # Populate the "seasons_name" input field with the series title
            seasons_name_input.clear()
            seasons_name_input.send_keys(f'SEASON {season}')

            order_input = driver.find_element(By.NAME, "order")
            order_input.clear()  # Clear any existing value
            order_input.send_keys('1')

            create_button = driver.find_element(By.XPATH, '/html/body/div[3]/div/div/div/div[2]/div[2]/form/div[3]/div/button[1]')
            create_button.click()

        
            wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
            next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
            next_button.click()


                    
                

            manage_episodes_button = driver.find_element(By.XPATH, f"//td[contains(., 'SEASON {season}')]/following-sibling::td/a[contains(., 'Manage Episodes')]"
)
            manage_episodes_button.click()

            wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
            next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
            next_button.click()

            
            for episode in range(1, number_of_episodes + 1):
                order_input = driver.find_element(By.NAME, "order")
                order_input.clear()
                order_input.send_keys(episode)

                episode_name_input = driver.find_element(By.XPATH, '//input[@type="text" and contains(@class, "form-control")]')
        
                episode_name_input.clear()

                import pandas as pd

                def find_row_with_values(series_title, season, episode):
                    print('passed')
                    df = pd.read_csv('NETNAIJAORGANIZEDSERIES_WITH_TRAILERS.csv')
                
                    # Filter the DataFrame based on the given criteria
                    mask = (df['SERIES_TITLE'] == series_title) & (df['SEASON'] == season) & (df['EPISODE'] == episode)
                    filtered_df = df[mask]
                
                    if not filtered_df.empty:
                        global row_series_title
                        global row_season_value
                        global row_series_link
                        global row_episode
                        row_series_title = filtered_df['SERIES_TITLE'].iloc[0]
                        row_season_value = filtered_df['SEASON'].iloc[0]
                        row_episode = filtered_df['EPISODE'].iloc[0]
                        row_series_link = filtered_df['LINK'].iloc[0]
                
                        print(f'ROW SERIES IS {row_series_title}')
                        print(f'ROW SEASON VALUE IS {row_season_value}')
                        print(f'ROW EPISODE IS {row_episode}')
                        print(f'ROW SERIES LINK IS {row_series_link}')
                
                        return row_series_title, row_season_value, row_episode, row_series_link
    
                            
    
                find_row_with_values(series_title, season, episode)
                episode_name_input.send_keys(f'EPISODE {row_episode}')
    
                image_input = driver.find_element(By.XPATH, '/html/body/main/div[2]/div[1]/div/div/div[2]/div/div[1]/form/div[3]/input')
                image_path = rf"C:\Users\benny\{movie_id}.jpg"
                image_input.send_keys(image_path)
            
            
    
    
                dropdown = driver.find_element(By.ID, "selected-source")
                select = Select(dropdown)
                select.select_by_value("youtube")
    
    
                series_link_input = driver.find_element(By.ID, "url-input-field")
                series_link_input.clear()
                print("2", youtube_url)
                series_link_input.send_keys(youtube_url)
    
                add_button = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[1]/div/div/div[2]/div/div[1]/form/div[7]/button")
                add_button.click()
    
    
                wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
                next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
                next_button.click()

            if len(seasons_list) == 1:
                back_to_seasons = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[1]/div/a[1]")
                back_to_seasons.click()

                wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
                next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
                next_button.click()
                
                episodes_download = driver.find_element(By.XPATH, "/html/body/main/div[2]/div/div/table/tbody/tr/td[5]/a[2]")
                episodes_download.click()
                
                for episode in range(1, number_of_episodes + 1):
                    
                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[1]/input")
                    element.send_keys(f'EPISODE {episode}')


                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[2]/input")
                    element.send_keys(f'480p')


                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[3]/input")
                    element.send_keys(f'70MB')


                    find_row_with_values(series_title, season, episode)
                    

                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[4]/input")
                    element.send_keys(row_series_link)

                    select_element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[5]/select")
                    select = Select(select_element)
                    select.select_by_value("1")

                    wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
                    next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
                    next_button.click()

                    submit = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/button")
                    submit.click()


    
                break
            else:
                back_to_seasons = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[1]/div/a[1]")
                back_to_seasons.click()
                    
                wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
                next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
                next_button.click()
                

                current_url = driver.current_url

                episodes_download = driver.find_element(By.XPATH, f"//td[contains(., 'SEASON {season}')]/following-sibling::td/a[contains(., 'Episodes download')]")
                episodes_download.click()
                
                for episode in range(1, number_of_episodes + 1):
                    
                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[1]/input")
                    element.send_keys(f'EPISODE {episode}')


                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[2]/input")
                    element.send_keys(f'480p')


                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[3]/input")
                    element.send_keys(f'70MB')


                    find_row_with_values(series_title, season, episode)
                    

                    element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[4]/input")
                    element.send_keys(row_series_link)

                    select_element = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/div[5]/select")
                    select = Select(select_element)
                    select.select_by_value("1")

                    wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
                    next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
                    next_button.click()

                    submit = driver.find_element(By.XPATH, "/html/body/main/div[2]/div[2]/div/div[1]/div[2]/div/form/button")
                    submit.click()



                driver.get(current_url)
                
                wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
                next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
                next_button.click()

                
                

         
        
        driver.get('https://flexcinemaz.com/admin/tvseries_add/')
        i += 1
        
        wait = WebDriverWait(driver, 100)  # Adjust the timeout as needed
        next_button = wait.until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[4]/div/div[4]/div/button')))
        next_button.click()
        
# Close the WebDriver
driver.quit()

with open("asian-anime.txt", "w") as file:
    for title in asian_anime:
        file.write(f"{title}\n")

print("Completed the task.")
