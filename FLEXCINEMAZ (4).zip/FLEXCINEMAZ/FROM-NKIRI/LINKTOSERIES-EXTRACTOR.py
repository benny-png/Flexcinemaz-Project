import csv
import re
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Define the base URL of the webpage to scrape movie data
base_url = "https://nkiri.com/tv-series-list"

# Function to extract and save series data to a CSV file
def extract_and_save_series_data():
    page_number = 1
    series_data = set()  # Use a set to automatically remove duplicates

    while page_number <= 4:  # Scrape up to 10 pages
        page_url = base_url if page_number == 1 else f"{base_url}-{page_number}/"
        driver.get(page_url)

        # Find all 'a' elements with the specified class and title
        series_elements = driver.find_elements(By.XPATH, '//a[@class="eael-grid-post-link" and @title]')

        for element in series_elements:
            title = element.get_attribute('title')
            link = element.get_attribute('href')
            # Use regular expression to extract the series title and season information
            match = re.search(r'^(.+?)\s+S(\d+)', title)
            if match:
                series_title = match.group(1).strip()
                season = match.group(2).strip()
                series_data.add((series_title, season, link))  # Add the data to the set to remove duplicates

        page_number += 1

    # Save the series data in a CSV file
    csv_filename = "series_data.csv"
    with open(csv_filename, 'w', newline='') as csvfile:
        fieldnames = ["series_title", "season", "link"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        writer.writerows({"series_title": title, "season": season, "link": link} for title, season, link in series_data)

    print(f"Series data extracted and saved to {csv_filename}")

# Call the function to extract and save series data
extract_and_save_series_data()

# Close the WebDriver
driver.quit()
