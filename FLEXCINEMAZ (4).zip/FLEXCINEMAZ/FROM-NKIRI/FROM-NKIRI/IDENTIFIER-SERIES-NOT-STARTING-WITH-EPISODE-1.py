import csv

# Read the CSV data into a list of dictionaries
data = []
with open('NETNAIJAORGANIZEDSERIES_WITH_TRAILERS.csv', 'r') as csvfile:
    csv_reader = csv.DictReader(csvfile)
    for row in csv_reader:
        data.append(row)

# Create a set to store series titles where the first occurrence doesn't start with "Episode 1"
first_non_episode_1_titles = set()

# Create a dictionary to keep track of whether a title has been seen with "Episode 1"
title_seen_with_episode_1 = {}

# Iterate through the data to identify series titles
for row in data:
    title = row['SERIES_TITLE']
    episode = int(row['EPISODE'])

    if title not in title_seen_with_episode_1:
        title_seen_with_episode_1[title] = episode

    if episode == 1 and title_seen_with_episode_1[title] == 1:
        continue

    if episode != 1 and title_seen_with_episode_1[title] != 1:
        first_non_episode_1_titles.add(title)

# Save the first occurrence of titles that don't start with "Episode 1" to a text file
with open('first_non_episode_1_titles.txt', 'w') as text_file:
    for title in first_non_episode_1_titles:
        text_file.write(title + '\n')

print(f"Series titles where the first occurrence doesn't start with 'Episode 1' saved to 'first_non_episode_1_titles.txt'.")
