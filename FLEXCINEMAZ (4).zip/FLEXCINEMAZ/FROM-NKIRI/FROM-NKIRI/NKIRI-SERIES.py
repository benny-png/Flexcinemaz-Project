import re
import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

# Initialize an empty list to store the movie data
movie_data = []

def extract_movie_data(movie_url):
    seen_movie_links = set()
    # Open the URL
    driver.get(movie_url)
    
    while True:
        movie_elements = driver.find_elements(By.CSS_SELECTOR, "a[href^='https://wetafiles.com/'], a[href^='https://downloadwella.com/']")
        
        if not movie_elements:
            break  # Exit the loop if no more elements are found
        
        for element in movie_elements:
            href = element.get_attribute("href")
            if href in seen_movie_links:
                return  # Exit the function if you encounter a repeated movie_link
            
            # Define the regular expression pattern to extract the movie title

            # Check if a match is found
            title = row['series_title']
             
            seen_movie_links.add(href)
            movie_data.append({"MOVIE_TITLE": title, "LINK": href})
            print(f"Scraped: {title} - {href}")

# Modify your code to pass the movie URL to the function
with open('series_data.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        link = row["link"]
        print(f"Scraping: {link}")
        extract_movie_data(link)
        print(f"Finished scraping: {link}")


# Read the series data from CSV and extract movie data for each series
with open('series_data.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        link = row["link"]
        print(f"Scraping: {link}")
        extract_movie_data(link)
        print(f"Finished scraping: {link}")

# Define the CSV filename to save the data
csv_filename = "NKIRISERIES.csv"

# Write the extracted movie data to a CSV file
with open(csv_filename, "w", newline="") as csvfile:
    fieldnames = ["MOVIE_TITLE", "LINK"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    writer.writerows(movie_data)

# Close the WebDriver
driver.quit()

print(f"Scraped {len(movie_data)} unique movie records and saved to {csv_filename}.")
