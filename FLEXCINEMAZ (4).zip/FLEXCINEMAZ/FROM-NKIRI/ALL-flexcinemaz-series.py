import csv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

# Configure Chrome options for the website
options = Options()
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Initialize the Chrome WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
driver.maximize_window()

# Define the URL of the webpage to open
login_url = "https://flexcinemaz.com/user/login"
tv_series_url = "https://flexcinemaz.com/admin/tvseries"

# Login to the website
driver.get(login_url)
input_element = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/input[1]')
input_element.clear()
input_element.send_keys("benjamin@flexcinemaz.com")

input_element = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/input[2]')
input_element.clear()
input_element.send_keys("benjamin@")
next_button = driver.find_element(By.XPATH, '/html/body/div[1]/div/div[1]/div/div/div[1]/div/div[2]/form/div[3]/button')
next_button.click()

# Function to extract series names from the current page
def extract_my_series_flexcinemaz():
    series_elements = driver.find_elements(By.XPATH, '//table[@id="datatablessd"]/tbody//td[4]/a/strong')
    series_names = [series_element.text for series_element in series_elements]
    return series_names

# Function to go to the next page
def go_to_next_page(page_number):
    next_page_url = f"https://flexcinemaz.com/admin/tvseries?&per_page={page_number * 10}"
    driver.get(next_page_url)

# Set the initial page number
current_page = 2  # Starting from page 2

# Open a single file to store all series names
with open('all_series_names.txt', 'w', encoding='utf-8') as file:
    while True:
        # Extract series names from the current page
        series_names = extract_my_series_flexcinemaz()

        # Write series names to the file
        for series_name in series_names:
            try:
                file.write(series_name + '\n')
            except UnicodeEncodeError as e:
                print(f"Skipping line due to UnicodeEncodeError: {e}")

        # Go to the next page
        go_to_next_page(current_page)

        # Wait for the next page to load (adjust the timeout as needed)
        WebDriverWait(driver, 10).until(EC.url_changes(tv_series_url))

        # Check if there are more pages to scrape
        if current_page >= 34:
            break

        # Increment the page number
        current_page += 1

# Close the WebDriver
driver.quit()
